﻿namespace Võ_Thị_Phương_Thảo_22103773_Asiggnment1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_menu = new System.Windows.Forms.Panel();
            this.lbl_sky = new System.Windows.Forms.Label();
            this.lbl_color = new System.Windows.Forms.Label();
            this.lbl_tree = new System.Windows.Forms.Label();
            this.pnl_control = new System.Windows.Forms.Panel();
            this.lbl_lamp = new System.Windows.Forms.Label();
            this.btn_push = new System.Windows.Forms.Button();
            this.btn_pull = new System.Windows.Forms.Button();
            this.pnl_menu.SuspendLayout();
            this.pnl_control.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_menu
            // 
            this.pnl_menu.BackColor = System.Drawing.Color.Pink;
            this.pnl_menu.Controls.Add(this.lbl_tree);
            this.pnl_menu.Controls.Add(this.lbl_color);
            this.pnl_menu.Controls.Add(this.lbl_sky);
            this.pnl_menu.ForeColor = System.Drawing.Color.Azure;
            this.pnl_menu.Location = new System.Drawing.Point(-7, 12);
            this.pnl_menu.Name = "pnl_menu";
            this.pnl_menu.Size = new System.Drawing.Size(807, 156);
            this.pnl_menu.TabIndex = 0;
            // 
            // lbl_sky
            // 
            this.lbl_sky.AutoSize = true;
            this.lbl_sky.BackColor = System.Drawing.Color.CornflowerBlue;
            this.lbl_sky.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sky.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lbl_sky.Location = new System.Drawing.Point(367, 59);
            this.lbl_sky.Name = "lbl_sky";
            this.lbl_sky.Size = new System.Drawing.Size(102, 33);
            this.lbl_sky.TabIndex = 1;
            this.lbl_sky.Text = "Yellow";
            this.lbl_sky.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_color
            // 
            this.lbl_color.AutoSize = true;
            this.lbl_color.BackColor = System.Drawing.Color.HotPink;
            this.lbl_color.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_color.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lbl_color.Location = new System.Drawing.Point(111, 59);
            this.lbl_color.Name = "lbl_color";
            this.lbl_color.Size = new System.Drawing.Size(68, 33);
            this.lbl_color.TabIndex = 1;
            this.lbl_color.Text = "Red";
            // 
            // lbl_tree
            // 
            this.lbl_tree.AutoSize = true;
            this.lbl_tree.BackColor = System.Drawing.Color.LightGreen;
            this.lbl_tree.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_tree.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.lbl_tree.Location = new System.Drawing.Point(605, 59);
            this.lbl_tree.Name = "lbl_tree";
            this.lbl_tree.Size = new System.Drawing.Size(96, 33);
            this.lbl_tree.TabIndex = 1;
            this.lbl_tree.Text = "Green";
            // 
            // pnl_control
            // 
            this.pnl_control.BackColor = System.Drawing.Color.PowderBlue;
            this.pnl_control.Controls.Add(this.btn_pull);
            this.pnl_control.Controls.Add(this.btn_push);
            this.pnl_control.Controls.Add(this.lbl_lamp);
            this.pnl_control.Location = new System.Drawing.Point(-7, 174);
            this.pnl_control.Name = "pnl_control";
            this.pnl_control.Size = new System.Drawing.Size(807, 276);
            this.pnl_control.TabIndex = 1;
            // 
            // lbl_lamp
            // 
            this.lbl_lamp.AutoSize = true;
            this.lbl_lamp.BackColor = System.Drawing.SystemColors.Info;
            this.lbl_lamp.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_lamp.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbl_lamp.Location = new System.Drawing.Point(70, 89);
            this.lbl_lamp.Name = "lbl_lamp";
            this.lbl_lamp.Size = new System.Drawing.Size(78, 33);
            this.lbl_lamp.TabIndex = 0;
            this.lbl_lamp.Text = "Light";
            // 
            // btn_push
            // 
            this.btn_push.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_push.Location = new System.Drawing.Point(399, 51);
            this.btn_push.Name = "btn_push";
            this.btn_push.Size = new System.Drawing.Size(70, 43);
            this.btn_push.TabIndex = 1;
            this.btn_push.Text = "On";
            this.btn_push.UseVisualStyleBackColor = true;
            // 
            // btn_pull
            // 
            this.btn_pull.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_pull.Location = new System.Drawing.Point(399, 158);
            this.btn_pull.Name = "btn_pull";
            this.btn_pull.Size = new System.Drawing.Size(75, 36);
            this.btn_pull.TabIndex = 2;
            this.btn_pull.Text = "Off";
            this.btn_pull.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnl_control);
            this.Controls.Add(this.pnl_menu);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.pnl_menu.ResumeLayout(false);
            this.pnl_menu.PerformLayout();
            this.pnl_control.ResumeLayout(false);
            this.pnl_control.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_menu;
        private System.Windows.Forms.Label lbl_tree;
        private System.Windows.Forms.Label lbl_color;
        private System.Windows.Forms.Label lbl_sky;
        private System.Windows.Forms.Panel pnl_control;
        private System.Windows.Forms.Button btn_pull;
        private System.Windows.Forms.Button btn_push;
        private System.Windows.Forms.Label lbl_lamp;
    }
}

